package Praktikum03;

public class InformasiMahasiswa {
    public String nama;
    public int NIM;
    public char jenisKelamin;
    public double IPK;
    
}
