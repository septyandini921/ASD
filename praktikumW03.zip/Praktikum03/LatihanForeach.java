package Praktikum03;

public class LatihanForeach {
    public static void main(String[] args) {
    int[] daftarNilai = new int[5];
    daftarNilai[0] = 7;
    daftarNilai[1] = 3;
    daftarNilai[2] = 8;
    daftarNilai[3] = 2;
    daftarNilai[4] = 1;

    for (int nilai : daftarNilai) {
        System.out.println(nilai);
    } 
    }
}
